README.txt - Mini Projet SD3
BINÔME: Ouiam Bendaia / Chaoui Sahar Rahma
DATE: 07 janvier 2026
UNIVERSITÉ: Badji Mokhtar – Annaba

CONTENU DU PROJET:

code/ : Fichiers Python (app.py et mini_projet_ecommerce.ipynb)
data/ : Dataset CSV utilisé
presentation/ : Présentation PowerPoint
README.txt : Ce fichier
INSTALLATION:

Installer les bibliothèques nécessaires:

pip install pandas numpy matplotlib seaborn plotly dash dash-bootstrap-components

Ou utiliser requirements.txt (si fourni):

pip install -r requirements.txt

EXÉCUTION:
Pour le Dashboard:
cd C:\Users\i\Desktop\Chaoui et Bendaia\ecommerce_dashboard(votre chemain)
dash-env\Scripts\activate 
python app.py
Puis ouvrir: http://127.0.0.1:8050
